<?php
    
	if(!class_exists('SL_teammate')) {

		class SL_teammate
		{

			function __construct()
			{
				add_action('init', array($this, 'init'));
				add_shortcode('single_teammate', array($this, 'sl_teammate_shortcode'));
			}

			function init()
			{

				if (function_exists("vc_map")) {

					vc_map(array(
						'name' => __('Single Teammate', 'sell'),
						'base' => 'single_teammate',
						'description' => __('Display Info About Single Teammate', 'sell'),
						'category' => __('SecretLab', 'sell'),
						//'admin_enqueue_css' => trailingslashit( plugins_url( 'sl_shortcodes' ) ) . 'css/admin.css',
						'icon' => 'ss-vc-icon icon-arrows-h',
						'params' => array(
							array(
								'type' => 'dropdown',
								'heading' => __('Teammates', 'sell'),
								'param_name' => 'teammate',
								'description' => __('', 'sell'),
								'group' => 'Content',
								'value' => $this->get_teammates()
							),
						)
					));

				}
			}

			function get_teammates()
			{

				$args = array('post_type' => array('teammate'),
					'orderby' => 'date',
					'order' => 'DESC');

				$teammates = new WP_Query($args);

				$out = array();

				foreach ($teammates->posts as $tm) {
					$out[$tm->post_title] = $tm->ID;
				}

				if (count($out > 0)) return $out; else return 'There is no teammates found';

			}

			function sl_teammate_shortcode($atts)
			{

				$defaults = array('teammate' => false);
				$args = vc_map_get_attributes('single_teammate', $atts);
				$set = shortcode_atts($defaults, $args);

				$out = '';

				if ($set['teammate']) {
					$tm = get_post($set['teammate']); // Take a post
					if (function_exists("types_render_field")) {
					$member_post = types_render_field("post-of-member", array("post_id" => $tm->ID, "output" => "normal"));
					$member_photo = types_render_field("photo-of-member", array("post_id" => $tm->ID, "output" => "raw"));


					$out .= get_the_title($tm->ID);
					$out .= '<div><img src="' . esc_url($member_photo) . '" alt="' . get_the_title($tm->ID) . '" ></div>';
					$out .= '<div>'.$member_post.'</div>';
				}

				return $out;

			}

		}

	}
	
	new SL_teammate();
	
	if(class_exists('WPBakeryShortCode'))
	{
		class WPBakeryShortCode_SL_teammate extends WPBakeryShortCode {
		}
	}	
	
?>
