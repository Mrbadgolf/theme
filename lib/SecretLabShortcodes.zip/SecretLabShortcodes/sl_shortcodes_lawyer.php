<?php

/*
Plugin Name: SecretLab Shortcodes for The Lawyer
Plugin URI: http://www.secretlab.pw/
Description: Additional shortcodes for Visual Composer 
Author: SecretLab
Version: 2.8.2
Author URI: http://www.secretlab.pw/
*/





	
add_action( 'vc_before_init', 'SL_integrateWithVC' );

function SL_integrateWithVC () { 

	class post_format {
		
		public $p;
		
		public function __construct () {
			
		}
		
		public function standart($p, $opts) {
            if ( is_sticky($p->ID) ) { $sticky = ' sticky'; } else { $sticky = ''; }
			$out = '<article id="'.$p->ID.'" class="post '.implode(' ', get_post_class('post', $p->ID)).$sticky.'">
						<header class="entry-header">';
				if ( has_post_thumbnail($p->ID) && $p->post_type != 'attachment' ) {
				$out .= '<div class="entry-thumbnail">'.
							get_the_post_thumbnail( $p->ID, array(1170, 560) ).
						'<div class="thumbhover"><a href="'.get_permalink($p->ID).'"><span class="icon-eye2"></span></a></div>
						</div>';
				} else {

				}
				$out .=	'<h3 class="entry-title">
							<a href="'.get_permalink($p->ID).'" rel="bookmark">'.get_the_title($p->ID).'</a>
						</h3>
						
						
						<div class="entry-meta">'.
							thelawyer_get_entry_meta(true, $p);
			if ( is_user_logged_in() ) {
				$out .= '<span class="edit-link"><a href="' . get_edit_post_link($p->ID, '') . '">' . __('Edit', 'sell') . '</a></span>';
			}
			$out .= '</div>
						</header>					
						
						<div class="entry-content">';
					if( !post_password_required( $p->ID ) ){
						if ( isset ( $opts ) && isset ( $opts['columns'] ) ) {
							if ( $opts['columns'] == 1 ) $out .= thelawyer_get_excerpt($p, null, 80);
							if ( $opts['columns'] == 2 ) $out .= thelawyer_get_excerpt($p, null, 50);
							if ( $opts['columns'] == 3 ) $out .= thelawyer_get_excerpt($p, null, 20);
						}
						else $out .= thelawyer_get_excerpt($p, null);
					} else {
						$out .= '<p>'. esc_html__( 'There is no excerpt because this is a protected post.', 'the-guard' ) .'</p>';
					}

			$out .= '<span class="date"> <a href="'.get_permalink($p->ID).'" title="'.get_the_title($p->ID).'" rel="bookmark"><time class="entry-date" datetime="'.get_the_date( 'F j, Y', $p->ID ).'">'.get_the_date( 'F j, Y', $p->ID ).'</time></a> <a href="'.get_permalink($p->ID).'" class="more-link">' . esc_html__('Continue reading', 'thelawyerlanguage') . ' <span class="meta-nav">&rarr;</span></a></span>
						</div>
					</article>';
					
				return $out;
				
		}		
		
    }

	function get_sl_option($option) {
		global $secretlab;

		if ( isset( $secretlab ) ) {
			if ( isset( $secretlab[$option] ) ) return $secretlab[$option];
			else return false;
		}
		else return false;
	}

	function get_registered_post_types() {
	
		global $wp_post_types, $wpdb;
		
		$pt = array();
		$post_types = $wpdb->get_results("SELECT DISTINCT post_type FROM wp_posts", ARRAY_N);
		
		foreach ($post_types as $n => $post_type) {
			$pt[] = $post_type[0];
		}

		return $pt;
	}

	function get_post_categories() {
		$cats = array('');
		$args = array ( 'hide_empty' => 0 );
		$categories = get_categories( $args );
		if( $categories ){
			foreach( $categories as $cat ){
				$cats[] = $cat->slug;
			}
			return $cats;
		}
		return false;
	}

	function get_site_posts() {
		$posts = get_posts(array('numberposts' => -1, 'post_type' => array('post', 'portfolio', 'testimonial', 'teammate')));
		$out = array('global post' => 0);
		foreach ($posts as $p) {
			$out[$p->post_title] = $p->ID;
		}
		return $out;
	}
	
add_shortcode( 'category_query', 'category_query_shortcode' );

	function category_query_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
		    'wrapperId'            => 'wrapperId',
			'column_layout'         => 1,
			'category'				=> '',
			'post_type'             => 'post',		
			'posts_per_page'        => -1,
			'npg'                   => 1,
			'read_more'            => 'Continue Reading'
		), $atts ) ); 

        if (isset($_POST['page'])) { $paged = $_POST['page']; $wrapperId = $_POST['id']; $base = $_POST['base']; $echo = true; } 
		else { $paged = 1; $base = get_pagenum_link( 999999999 ); $echo = false; }
		if (isset($_POST['cat'])) { $category = $_POST['cat']; }
		if (isset($_POST['pt'])) { $post_type = $_POST['pt']; }
		if (isset($_POST['ppp'])) { $posts_per_page = $_POST['ppp']; }
        if (isset($_POST['npg'])) { $npg = $_POST['npg']; }		
        
		$output = '';

		$column_classes = array ( '1' => ' onecolumnnsb', '2' => ' blog2columnpage', '3' => ' blog3columnpage' );
		if (isset($column_layout)) {
			if (isset($column_classes[ $column_layout ])) {
				$columns = $column_classes[ $column_layout ];
			}
			else {
				$columns = ' onecolumnnsb';
			}
		}

		$args = array ( 'category_name' => $category,
						'post_type' => explode(',', $post_type),
						'posts_per_page' => $posts_per_page,
						'ignore_sticky_posts' => false,
						'paged' => $paged,
						'orderby' => 'date',
						'order' => 'DESC' );
							
		$cat_posts = new WP_Query($args);
		
		//Output posts
		
		if ( $cat_posts->posts ) :
		
			if (!isset($g)) 
			$g = new post_format();
		
			// Loop through posts
			
			foreach ( $cat_posts->posts as $post ) :
				// Post VARS
				$pid  = $post->ID;
				$p = $post;

				//$output .= $g->standart($post); continue;
				if ( is_sticky($pid) ) { $sticky = ' sticky'; } else { $sticky = ''; }
				$output .= '<article id="'.$pid.'" class="post '.implode(' ', get_post_class('post', $pid)).$sticky.'">';

				$output .=	'<header class="entry-header">';
            				if ( has_post_thumbnail($pid) && $p->post_type != 'attachment' ) {
					$output .= '<div class="entry-thumbnail">'.
						get_the_post_thumbnail( $pid, array(1170, 560) ).
						'<div class="thumbhover"><a href="'.get_permalink($p->ID).'"><span class="icon-eye2"></span></a></div>
						</div>';
				}
				$output .= '<h3 class="entry-title">
							<a href="'.get_permalink($pid).'" rel="bookmark">'.get_the_title($pid).'</a>
							</h3>
							<div class="entry-meta">'.thelawyer_get_entry_meta(true, $p);
					if ( is_user_logged_in() ) {
				$output .= '<span class="edit-link"><a href="' . get_edit_post_link($p->ID, '') . '">' . __('Edit', 'sell') . '</a></span>';
			}
							$output .= '</div>
						</header>					
						
						<div class="entry-content">';
				if( !post_password_required( $p->ID ) ){
						if ( isset ( $column_layout ) ) {
							if ( $column_layout == 1 ) $output .= thelawyer_get_excerpt($p, null, 80);
							if ( $column_layout == 2 ) $output .= thelawyer_get_excerpt($p, null, 50);
							if ( $column_layout == 3 ) $output .= thelawyer_get_excerpt($p, null, 20);
						}
						else $output .= thelawyer_get_excerpt($p, null);
					} else {
						$output .= '<p>'. esc_html__( 'There is no excerpt because this is a protected post.', 'the-guard' ) .'</p>';
					}


				$output .= '<span class="date"> <a href="'.get_permalink($p->ID).'" title="'.get_the_title($p->ID).'" rel="bookmark"><time class="entry-date" datetime="'.get_the_date( 'F j, Y', $p->ID ).'">'.get_the_date( 'F j, Y', $p->ID ).'</time></a> <a href="'.get_permalink($p->ID).'" class="more-link">' . $read_more . ' <span class="meta-nav">&rarr;</span></a></span>
						</div>
					</article>';

				
			endforeach;
				
		endif; // End has posts check	
		
        $waiter = '<img id="lawyer_ajax_waiter" src="' . get_template_directory_uri() . '/images/ajax-loader2.gif' .'" style="position:absolute; display:none;" alt="Page is loading...">';
		$output .= $waiter;
		
	    $args = array(
		    'base' => str_replace( 999999999, '%#%', $base ),
		    'format' => '',
		    'current' => max( 1, $paged ),
		    'total' => $cat_posts->max_num_pages,
		    'prev_next' => false,
			'type' => 'array'
	    );

        $result = paginate_links( $args );	
		//$result = str_replace( '/page/1/', '', $result );
		
		if (count($result) > 0 && $npg) {
		    $output .= '<div class="category_query_pagination blogpagination">'.
		               implode(' ', preg_replace('/\/page/', '/_id='.$wrapperId.'_cat='.$category.'_pt='.$post_type.'_ppp='.$posts_per_page.'/page', $result)).
					   '<div id="category_query_service_info" style="display : none;">' . $base . '</div>
					</div>';
		}
		
				
		// Set things back to normal
		$cat_posts = null;
		wp_reset_postdata();

		// Return output
		if (!$echo) {
		    return '<div class="category_query_block'.$columns.'">'.$output.'</div>'; 	
		}
		else {
		    echo $output;
		}
		
	}	

add_action( 'wp_ajax_handle_category_query', 'category_query_shortcode' );
add_action( 'wp_ajax_nopriv_handle_category_query', 'category_query_shortcode' );	
	
	vc_map( array(
		'name'        => __( 'Posts by post-type and category', 'sell' ),
		'base'        => 'category_query',
		'description' => __( 'Get posts by category', 'sell' ),
		'category'    => __( 'SecretLab', 'symple' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Wrapper block CSS Class', 'sell' ),
				'param_name'	=> 'wrapper_id',
				'description'	=> __( 'this string will be used as class list for the wrapper block', 'sell' ),
				'value'         => ''
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Select column layout', 'sell' ),
				'param_name'	=> 'column_layout',
				'description'	=> __( 'set one, two or three columns', 'sell' ),
				'value'         => array ( '1 Column' => 1,
										   '2 Columns' => 2,
										   '3 Columns' => 3 ),
                'std'       => 1
			),			
			array(
				'type'			=> 'posttypes', //'dropdown',
				'heading'		=> __( 'Post type', 'sell' ),
				'param_name'	=> 'post_type',
				'description'	=> __( 'Select needed post-type', 'sell' ),
				//'value'         => array_merge(array(''=>'any'), get_registered_post_types())
			),				
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Category', 'sell' ),
				'param_name'	=> 'category',
				'description'	=> __( 'Attention! this list can be applied to POST post_type only', 'sell' ),
				'value'         => get_post_categories()
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts per page', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page, if you want to get all posts - type "-1" here', 'sell' ),
				'value'         => 3
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Use Pagination', 'sell' ),
				'param_name'	=> 'npg',
				'description'	=> __( '', 'sell' ),
				'value'         => array( 'yes' => 1,
				                          'no'  => 0 ),
				'std'           => 1
			),
			array(
				'type'          => 'textfield',
				'heading'       => 'Read more link text',
				'param_name'    => 'read_more',
				'value'         => 'Continue reading'
			),
			
		)
	));
	
	
	add_shortcode( 'testimonial_query', 'testimonial_query_shortcode' );

	function testimonial_query_shortcode($atts, $content = null) {	
		extract( shortcode_atts( array(
			'uid'              => '',
			'posts_per_page'   => '',
			'offset'           => '',
			'extra_class'	   => null,
			'enable_nav'       => 'false',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );
		
		global $secretlab;
		
			$slick_params = array( 'class'      => $extra_class ? $extra_class : 'testimonials_box',
						 'enable_nav' => $enable_nav,
						 'autoplay'   => $autoplay,
						 'speed'      => $speed ? $speed : 5000,
						 'dots'       => 'true',
						 'arrows'     => 'false',
						 'sp_row'     => 2,
						 'sp_show'    => 2,
						 'sp_scroll'  => 2,
						 '961' => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ),
						 '768' => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ),
				);
			$secretlab['slick'][] = $slick_params;			 
		 

		$result = new WP_query('post_type=testimonial&posts_per_page='.$posts_per_page.'&offset='.$offset);
	   
		$output = '';
		
		//Output posts
		
		if ( $result->posts ) :	
			
			add_action('wp_footer', 'thelawyer_add_slick_carousel');
		
		
			//$unique_id = $unique_id ? ' id="'. $unique_id .'"' : null;
		
			// Main wrapper div
			
			$output .= '<div class="carousel '.$slick_params['class'].'">'; 
		
			// Loop through posts
			foreach ( $result->posts as $post ) :
			
				// Post VARS
				$post_id          = $post->ID;

				if (function_exists("types_render_field")) {
					$client_name = types_render_field("name-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_post = types_render_field("post-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_photo = types_render_field("photo-of-client", array("post_id" => $post_id, "url" => "true"));
				} else {$client_name = $client_post = $client_photo = '';}
					// Testimonial post article start			
				
					// Open details div
					$output .= ' <div class="item" id="post-'. $post_id .'">
									<div class="bubbles">
										<div class="mention">
											<p>'.
											$post->post_content.
											'</p>
										</div>
										<div class="face">'.
											'<a href="'.get_permalink($post_id).'"><img src="'.$client_photo.'" alt=""></a><strong>'.$client_name.'</strong><p>'.$client_post.'</p>
										</div>
									</div>
								</div>';
								

			
			// End foreach loop
			endforeach;
			
			$output .= '</div>';

		
		endif; // End has posts check	

		
				
		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;    
		
	}

	vc_map( array(
		'name'        => __( 'Testimonials with carousel', 'sell' ),
		'base'        => 'testimonial_query',
		'description' => __( 'Get testimonial post_type posts', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Unique ID', 'sell' ),
				'param_name'	=> 'uid',
				'description'	=> __( 'May be used for styling', 'sell' ),
			),	
			/*array(
				'type'			=> 'textfield',
				'heading'		=> __( 'ClassName', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'extra css class', 'sell' )
			),*/		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 3
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Offset for query', 'sell' ),
				'param_name'	=> 'offset',
				'description'	=> __( 'start offset', 'sell' ),
				'value'         => 0
			),			
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'set aviability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),			
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)		
			
		)
	));


	add_shortcode( 'digital_testimonial_query', 'digital_testimonial_query_shortcode' );

	function digital_testimonial_query_shortcode($atts, $content = null) {	
		extract( shortcode_atts( array(
			'uid'              => '',
			'posts_per_page'   => '',
			'extra_class'	   => null,
			'enable_nav'       => 'false',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );
		
		global $secretlab;
		
			$slick_params = array( 'class'      => $extra_class ? $extra_class : 'digital_testimonials_box',
						 'enable_nav' => $enable_nav,
						 'autoplay'   => $autoplay,
						 'speed'      => $speed ? $speed : 5000,
						 'dots'       => 'true',
						 'arrows'     => 'false',
						 'sp_row'     => 1,
						 'sp_show'    => 1,
						 'sp_scroll'  => 1);
			$secretlab['slick'][] = $slick_params;			 
		 

		$result = new WP_query('post_type=testimonial&posts_per_page='.$posts_per_page);
	   
		$output = '';
		
		//Output posts
		
		if ( $result->posts ) :	
			
			add_action('wp_footer', 'thelawyer_add_slick_carousel');
		
			// Main wrapper div
			
			$output .= '
				<div class="text-center paddingleft">
					<div id="digitalti" class="carousel '.$slick_params['class'].'">'; 
		
			// Loop through posts
			foreach ( $result->posts as $post ) :
			
				// Post VARS
				$post_id          = $post->ID;

				if (function_exists("types_render_field")) {
					$client_name = types_render_field("name-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_post = types_render_field("post-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_photo = types_render_field("photo-of-client", array("post_id" => $post_id, "url" => "true"));
				} else {$client_name = $client_post = $client_photo = '';}
					// Testimonial post article start			
				
					// Open details div
					$output .= '<div class="item">
										<div class="mention">
											<p>'.
											$post->post_content.
											'</p>
										</div>
										<div class="face">'.
											'<a href="'.get_permalink($post_id).'"><img src="'.$client_photo.'" alt=""></a><strong>'.$client_name.'</strong><p>'.$client_post.'</p>
										</div>
								</div>';
								

			
			// End foreach loop
			endforeach;
			
			$output .= '</div>
					 </div>';

		
		endif; // End has posts check	

		
				
		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;    
		
	}

	vc_map( array(
		'name'        => __( 'Testimonials with carousel Layout#2', 'sell' ),
		'base'        => 'digital_testimonial_query',
		'description' => __( 'Get testimonial post_type posts', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'ClassName', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'CSS class for carousel HTML container', 'sell' )
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 3
			),		
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),			
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)		
			
		)
	));

	/* Testimonial Layout 3 for The Lawyer Theme */
	add_shortcode( 'testimonial_query_3_thelawyer', 'testimonial_query_shortcode_3_thelawyer' );

	function testimonial_query_shortcode_3_thelawyer($atts, $content = null) {	
		extract( shortcode_atts( array(
			'uid'              => '',
			'posts_per_page'   => '',
			'extra_class'	   => null,
			'enable_nav'       => 'false',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );
		
		global $secretlab;
		
			$slick_params = array( 'class'      => $extra_class ? $extra_class : 'testimonials_box_third',
						 'enable_nav' => $enable_nav,
						 'autoplay'   => $autoplay,
						 'speed'      => $speed ? $speed : 5000,
						 'dots'       => 'false',
						 'arrows'     => 'true',
						 'prevArrow'  => '<div class="slick-prev">prev</div>',
						 'nextArrow'  => '<div class="slick-next">next</div>',
						 'sp_row'     => 1,
						 'sp_show'    => 1,
						 'sp_scroll'  => 1);
			$secretlab['slick'][] = $slick_params;			 
		 

		$result = new WP_query('post_type=testimonial&posts_per_page='.$posts_per_page);
	   
		$output = '';
		
		//Output posts
		
		if ( $result->posts ) :	
			
			add_action('wp_footer', 'thelawyer_add_slick_carousel');
		
			// Main wrapper div
			
			$output .= '
				<div class="text-center paddingleft">
					<div id="digitalti" class="layout3 carousel '.$slick_params['class'].'">'; 
		
			// Loop through posts
			foreach ( $result->posts as $post ) :
			
				// Post VARS
				$post_id          = $post->ID;

				if (function_exists("types_render_field")) {
					$client_name = types_render_field("name-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_post = types_render_field("post-of-client", array("post_id" => $post_id, "output"=>"normal"));
					$client_photo = types_render_field("photo-of-client", array("post_id" => $post_id, "url" => "true"));
				} else {$client_name = $client_post = $client_photo = '';}
					// Testimonial post article start			
				
					// Open details div
					$output .= '<div class="item">
										<a href="'.get_permalink($post_id).'"><img src="'.$client_photo.'" alt=""></a>
										<div class="mention">
											<p>'.
											$post->post_content.
											'</p>
										</div>
										<div class="face">'.
											'<strong>'.$client_name.'</strong><p>'.$client_post.'</p>
										</div>
								</div>';
								

			
			// End foreach loop
			endforeach;
			
			$output .= '</div>
					 </div>';

		
		endif; // End has posts check	

		
				
		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;    
		
	}

	vc_map( array(
		'name'        => __( 'Testimonials with carousel Layout#3', 'sell' ),
		'base'        => 'testimonial_query_3_thelawyer',
		'description' => __( 'Get testimonial post_type posts', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'ClassName', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'CSS class for carousel HTML container', 'sell' )
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 5
			),		
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'set ability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),			
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)		
			
		)
	));

	/* Testimonial Layout #4 for The Lawyer and The Repair Themes */
	add_shortcode( 'testimonial_query_4', 'testimonial_query_4_shortcode' );

	function testimonial_query_4_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
			'uid'              => '',
			'posts_per_page'   => '',
			'extra_class'	   => null,
			'enable_nav'       => 'true',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );

		global $secretlab;

		$slick_params = array( 'class'      => $extra_class ? $extra_class : 'testi_box_four',
			'enable_nav' => $enable_nav,
			'autoplay'   => $autoplay,
			'speed'      => $speed ? $speed : 5000,
			'dots'       => 'true',
			'arrows'     => 'false',
			'sp_row'     => 1,
			'sp_show'    => 2,
			'sp_scroll'  => 2,
			'768' => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ));
		$secretlab['slick'][] = $slick_params;


		$result = new WP_query('post_type=testimonial&posts_per_page='.$posts_per_page);

		$output = '';

		//Output posts

		if ( $result->posts ) :

			add_action('wp_footer', 'thelawyer_add_slick_carousel');

			// Main wrapper div

			$output .= '<div class="carousel '.$slick_params['class'].'">';

			// Loop through posts
			foreach ( $result->posts as $post ) :

				// Post VARS
				$post_id          = $post->ID;
				if (function_exists("types_render_field")) {
				$client_name = types_render_field("name-of-client", array("post_id" => $post_id, "output"=>"normal"));
				$client_post = types_render_field("post-of-client", array("post_id" => $post_id, "output"=>"normal"));
				$client_photo = types_render_field("photo-of-client", array("post_id" => $post_id, "url" => "true"));
				} else {$client_name = $client_post = $client_photo = '';}
				// Testimonial post article start

				// Open details div
				$output .= '<div class="item">
										<div class="mention">
											<p>'.thelawyer_get_excerpt($post, null, 55).'</p>
										</div>
										<div class="face">'.
											'<a href="'.get_permalink($post_id).'"><img src="'.$client_photo.'" alt=""></a><strong>'.$client_name.'</strong>
										</div>
								</div>';



				// End foreach loop
			endforeach;

			$output .= '</div>';


		endif; // End has posts check



		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;

	}

	vc_map( array(
		'name'        => __( 'Testimonials. Layout #4', 'sell' ),
		'base'        => 'testimonial_query_4',
		'description' => __( 'Displays testimonials with 2 columns and carousel', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Unique ID', 'sell' ),
				'param_name'	=> 'uid',
				'description'	=> __( 'May be used for styling', 'sell' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Testimonials quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many testimonials displays on the page', 'sell' ),
				'value'         => 6
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Offset for query', 'sell' ),
				'param_name'	=> 'offset',
				'description'	=> __( 'start offset', 'sell' ),
				'value'         => 0
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'Sets avialability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
					'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'Sets autoplay option', 'sell' ),
				'value'         => array( 'disable' => 'false',
					'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between autoplay slides', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)

		)
	));


	/* 2 Columns Blog Feed */
	add_shortcode( 'archive_format_post', 'archive_format_post_shortcode' );

	function archive_format_post_shortcode($atts, $content = null) {	
		extract( shortcode_atts( array(
			'q'                => '',
			'npg'              => 0
		), $atts ) );	

        if (isset($_POST['page'])) { $paged = $_POST['page']; $wrapperId = $_POST['id']; $base = $_POST['base']; $echo = true; } 
		else { $paged = 1; $base = get_pagenum_link( 999999999 ); $echo = false; }	
		if (isset($_POST['ppp'])) { $q = $_POST['ppp']; }
        if (isset($_POST['npg'])) { $npg = $_POST['npg']; }

        $out = '';

        $args = array(  'posts_per_page' => $q,
		                'ignore_sticky_posts' => true,
						'paged' => $paged,
						'orderby' => 'date',
						'order' => 'DESC' 					   
                     );		
		
        $result = new WP_query( $args );
	
		if ( $result->posts ) :	
			
			foreach ( $result->posts as $p ) :
			
				$out .= '<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 digital-format">
							<article class="post format-standard has-post-thumbnail clearfix">
								<header class="entry-header">';
								if ( has_post_thumbnail($p->ID) && $p->post_type != 'attachment' ) {
								$out .= 
									'<div class="entry-thumbnail">'.
										get_the_post_thumbnail( $p->ID, 'thelawyer_smalldigital' ).
									'</div>';
									
								} else {
									$out .= '<div class="entry-thumbnail"></div>';
								}
								$out.= 
									'<h3 class="entry-title">';
										$title = get_the_title($p->ID);
										$t = explode(' ', $title);
										if (count($t) > 6) { $title = implode(' ', array_slice($t, 0, 6, true))."..."; }
										$out .= '<a href="'.get_permalink($p->ID).'" rel="bookmark">'.$title.'</a>
									</h3>';
									$author = get_user_by('id', $p->post_author);
									$out .= '
									<div class="entry-meta">
										<span class="author vcard">BY '.strtoupper($author->user_login).'</span>
										<span class="date">
											<time class="entry-date" datetime="'.get_the_date("c", $p->ID).'">'.strtoupper(get_the_date("F n, Y", $p->ID)).'</time>
										</span>
									</div>
								</header>
								<div class="entry-content">';
									//thelawyer_get_content($p, 'MORE<span class="icon icon-arrow-right8"></span>').

				if( !post_password_required( $p->ID ) ){
					$content = thelawyer_get_excerpt($p, null, 12).'<a class="more-link" href="'.get_permalink($p->ID).'">MORE <span class="icon icon-arrow-right"></span></a>';
				} else {
					$content = '<p>'.esc_html__( 'There is no excerpt because this is a protected post.', 'the-guard' ).'</p>';
				}
									$out .= $content.
								'</div>
							</article>
						</div>';
						
			endforeach;

            $waiter = '<img id="lawyer_ajax_waiter" src="' . get_template_directory_uri() . '/images/ajax-loader2.gif' .'" style="position:absolute; display:none;">';		
		    $out .= $waiter;			
		
		endif; // End has posts check	

	    $args = array(
		    'base' => str_replace( 999999999, '%#%', $base ),
		    'format' => '',
		    'current' => max( 1, $paged ),
		    'total' => $result->max_num_pages,
		    'prev_next' => false,
			'type' => 'array'
	    );	

        $result = paginate_links( $args );

		if (count($result) > 0 && $npg) {
		    $out .= '<div class="post_format_query_pagination blogpagination">'.
		               implode(' ', preg_replace('/\/page/', '/_id=afp_ppp='.$q.'_npg='.$npg.'/page', $result)).
					   '<div id="post_format_query_service_info" style="display : none;">' . $base . '</div>
					</div>';
		}			
		
		wp_reset_postdata();

		if (!$echo) {
		    return '<div class="post_format_query_block">'.$out.'</div>'; 	
		}
		else {
		    echo $out;
		}    
		
	}
	
add_action( 'wp_ajax_handle_post_format_query', 'archive_format_post_shortcode' );
add_action( 'wp_ajax_nopriv_handle_post_format_query', 'archive_format_post_shortcode' );	

	vc_map( array(
		'name'        => __( 'Blog Feed, 2 columns', 'sell' ),
		'base'        => 'archive_format_post',
		'description' => __( 'Show Any Post in Archive Format', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(	
			array(
				'type'          => 'textfield',
				'heading'       => 'Type Number of Posts to Show',
				'param_name'    => 'q',		
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Use Pagination', 'sell' ),
				'param_name'	=> 'npg',
				'description'	=> __( '', 'sell' ),
				'value'         => array( 'yes' => 1,
				                          'no'  => 0 ),
				'std'           => 0
			),			
			
		)
	));



	add_shortcode( 'teammate_query', 'teammate_shortcode' );

	function teammate_shortcode($atts, $content = null) {	
		extract( shortcode_atts( array(
			'uid'              => '',
			'main_title'       => '',
			'description'      => '',
			'posts_per_page'   => 5,
			'extra_class'	   => null,
			'enable_nav'       => 'false',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );
		
		global $secretlab;
		
			$slick_params = array( 'class'      => $extra_class ? $extra_class : 'teammate_box',
						 'enable_nav' => $enable_nav,
						 'autoplay'   => $autoplay,
						 'speed'      => $speed ? $speed : 5000,
						 'dots'       => 'false',
						 'arrows'     => 'true',
						 'infinite'	=> 'false',
						 'sp_row'     => 1,
						 'sp_show'    => 2,
						 'sp_scroll'  => 2,
						 '961'        => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ),
						 '768'        => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ),
						 );	
			$secretlab['slick'][] = $slick_params;			 

		$result = new WP_query('post_type=teammate&posts_per_page='.$posts_per_page);
	   
		$output = '';
		
		//Output posts
		
		if ( $result->posts ) :	
			
			add_action('wp_footer', 'thelawyer_add_slick_carousel');

				$output .=  '<div id="team-index" class="carousel '.$slick_params['class'].'">';
		
			// Loop through posts
			foreach ( $result->posts as $post ) :
			
				// Post VARS
				$post_id          = $post->ID;
				if (function_exists("types_render_field")) {
					$member_post = types_render_field("post-of-member", array("post_id" => $post_id, "output"=>"normal"));
					$member_photo = types_render_field("photo-of-member", array("post_id" => $post_id, "output"=>"raw"));
					$fb_profile = types_render_field("facebook-profile", array("post_id" => $post_id, "output"=>"normal"));
					$yt_profile = types_render_field("youtube-profile", array("post_id" => $post_id, "output"=>"normal"));
					$tw_profile = types_render_field("twitter-profile", array("post_id" => $post_id, "output"=>"normal"));
					$bh_profile = types_render_field("behance-profile", array("post_id" => $post_id, "output"=>"normal"));
					$ln_profile = types_render_field("linkedin-profile", array("post_id" => $post_id, "output"=>"normal"));
					$sell_memberphone = types_render_field("thelawyer_member_phone", array("post_id" => $post_id, "output"=>"normal"));
                    $sell_memberemail = types_render_field("thelawyer_member_email", array("post_id" => $post_id, "output"=>"normal"));
				} else {$member_post = $member_photo = $fb_profile = $yt_profile = $tw_profile = $bh_profile = $ln_profile = $sell_memberphone = $sell_memberemail = '';}
					$excerpt = get_the_excerpt($post);
				
					$output .= '<div class="item">
								   <div class="teamprphoto" style="background-image: url('.$member_photo.')">
								   <div class="overmember">
									   <a href="'.get_permalink($post_id).'">
										   <i class="icon-link"></i>
									   </a>
								   </div></div>
								   <strong><a href="'.get_permalink($post_id).'">'.$post->post_title.'</a></strong>
								   <span class="desrdivider">'.$member_post.'</span>
								   <div class="teammate">
									<p>'.$excerpt.'</p>
								   <ul class="contact-list">';

									if (!empty($fb_profile) or !empty($yt_profile) or !empty($tw_profile) or !empty($bh_profile) or !empty($ln_profile)) {
                                    $output .= '<li class="socialprofiles">';
								   }
										if (!empty($fb_profile)) {
										   $output .= '<a href="'.$fb_profile.'"><i class="icon-facebook"></i></a>';
									   }
											if (!empty($yt_profile)) {
										   $output .= '<a href="'.$yt_profile.'"><i class="icon-youtube-play"></i></a>';
									   }
											if (!empty($tw_profile)) {
										   $output .= '<a href="'.$tw_profile.'"><i class="icon-twitter"></i></a>';
									   }
											if (!empty($bh_profile)) {
										   $output .= '<a href="'.$bh_profile.'"><i class="icon-behance"></i></a>';
									   }
										if (!empty($ln_profile)) {
										   $output .= '<a href="'.$ln_profile.'"><i class="icon-linkedin"></i></a>';
									   }
                                   if (!empty($fb_profile) or !empty($yt_profile) or !empty($tw_profile) or !empty($bh_profile) or !empty($ln_profile)) {
                                    $output .= '</li>';
								   }
                            $output .= '</ul>
							</div>';
								   $output .= '
								</div>';


			
			// End foreach loop
			endforeach;
			
			$output .= '</div>';

		
		endif; // End has posts check	

		
				
		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;    
		
	}

	vc_map( array(
		'name'        => __( 'Teammates with carousel', 'sell' ),
		'base'        => 'teammate_query',
		'description' => __( 'Get teammate post_type posts', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			/*array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Unique ID', 'sell' ),
				'param_name'	=> 'uid',
				'description'	=> __( 'May be used for styling with CSS', 'sell' ),
			),	*/
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 10
			),			
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'set ability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),			
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides in ms', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)		
			
		)
	));

	/* Team Shortcode: Second Layout  */
	add_shortcode( 'teammate_query_second', 'teammate_shortcode_second' );

	function teammate_shortcode_second($atts, $content = null) {	
		extract( shortcode_atts( array(
			'extra_class'      => '',
			'main_title'       => '',
			'description'      => '',
			'posts_per_page'   => '',
			'enable_nav'       => 'true',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );
		
		
		global $secretlab;
		
			$slick_params = array( 'class'      => $extra_class ? $extra_class : 'teammate_box_second',
						 'enable_nav' => $enable_nav,
						 'autoplay'   => $autoplay,
						 'speed'      => $speed ? $speed : 5000,
						 'dots'       => 'true',
						 'arrows'     => 'false',
						 'sp_row'     => 3,
						 'sp_show'    => 3,
						 'sp_scroll'  => 3,
						 '961'        => array ( 'sp_row' => 2, 'sp_show' => 2, 'sp_scroll' => 2 ),
						 '768'        => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 ),
						 );
			$secretlab['slick'][] = $slick_params;
        
		$result = new WP_query('post_type=teammate&posts_per_page='.$posts_per_page);
	   
		$output = '';
		
		//Output posts
		
		if ( $result->posts ) :	
			
			add_action('wp_footer', 'thelawyer_add_slick_carousel');

				$output .=  '<div id="teamsecond" class="carousel '.$slick_params['class'].' team-slide">';
		
			// Loop through posts
			foreach ( $result->posts as $post ) :
			
				// Post VARS
				$post_id          = $post->ID;
				if (function_exists("types_render_field")) {
					$member_post = types_render_field("post-of-member", array("post_id" => $post_id, "output"=>"normal"));
					$member_photo = types_render_field("photo-of-member", array("post_id" => $post_id, "output"=>"raw"));
					$fb_profile = types_render_field("facebook-profile", array("post_id" => $post_id, "output"=>"normal"));
					$yt_profile = types_render_field("youtube-profile", array("post_id" => $post_id, "output"=>"normal"));
					$tw_profile = types_render_field("twitter-profile", array("post_id" => $post_id, "output"=>"normal"));
					$bh_profile = types_render_field("behance-profile", array("post_id" => $post_id, "output"=>"normal"));
					$ln_profile = types_render_field("linkedin-profile", array("post_id" => $post_id, "output"=>"normal"));
					$sell_memberphone = types_render_field("thelawyer_member_phone", array("post_id" => $post_id, "output"=>"normal"));
                    $sell_memberemail = types_render_field("thelawyer_member_email", array("post_id" => $post_id, "output"=>"normal"));
				} else {$member_post = $member_photo = $fb_profile = $yt_profile = $tw_profile = $bh_profile = $ln_profile = $sell_memberphone = $sell_memberemail = '';}

					$output .= '<div class="team-item">
								<div class="meta-info">';
					if (!empty($sell_memberphone)) {
						$output .= '<span><span class="icon-phone2 mrgr10"></span> <a href="'.get_permalink($post_id).'" rel="bookmark">'.$sell_memberphone.'</a></span>';
					}
					if (!empty($sell_memberemail)) {
						$output .= '<span><span class="icon-envelope mrgr10"></span> <a href="'.get_permalink($post_id).'" rel="bookmark">'.$sell_memberemail.'</a></span>';
					}
					$output .= '</div>
							<div class="photo">
								<img src="'.$member_photo.'" alt="" class="img-responsive"/>
								<div class="team-overlay">
									<p class="team-overlay-link">';
					if (!empty($fb_profile)) {
						$output .= '<a href="'.$fb_profile.'"><i class="icon-facebook"></i></a>';
					}
					if (!empty($yt_profile)) {
						$output .= '<a href="'.$yt_profile.'"><i class="icon-youtube-play"></i></a>';
					}
					if (!empty($tw_profile)) {
						$output .= '<a href="'.$tw_profile.'"><i class="icon-twitter"></i></a>';
					}
					if (!empty($bh_profile)) {
						$output .= '<a href="'.$bh_profile.'"><i class="icon-behance"></i></a>';
					}
					if (!empty($ln_profile)) {
						$output .= '<a href="'.$ln_profile.'"><i class="icon-linkedin"></i></a>';
					}
					$output .= '</p>
								</div>
							</div>
							<div class="main-info">
								<span class="name">'.$post->post_title.'</span>
								<span class="regalies">'.$member_post.'</span>
							</div>
						</div>';

			
			// End foreach loop
			endforeach;
			
			$output .= '</div>';

		
		endif; // End has posts check	

		
				
		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;    
		
	}

	vc_map( array(
		'name'        => __( 'Teammates with carousel 2', 'sell' ),
		'base'        => 'teammate_query_second',
		'description' => __( 'Get teammate post_type posts', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Extra Class Name', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'May be used for styling with CSS', 'sell' ),
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 10
			),			
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'set ability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
										  'enable'  => 'true', ),			
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides in ms', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)		
			
		)
	));

	/* Team #3 */
	add_shortcode( 'teammate_query_third', 'teammate_shortcode_third' );

	function teammate_shortcode_third($atts, $content = null) {
		extract( shortcode_atts( array(
			'extra_class'      => '',
			'main_title'       => '',
			'description'      => '',
			'posts_per_page'   => '',
			'enable_nav'       => 'true',
			'autoplay'         => 'false',
			'speed'            => '5000'
		), $atts ) );


		global $secretlab;

		$slick_params = array( 'class'      => $extra_class ? $extra_class : 'teammate_box_third',
			'enable_nav' => $enable_nav,
			'autoplay'   => $autoplay,
			'speed'      => $speed ? $speed : 5000,
			'dots'       => 'true',
			'arrows'     => 'false',
			'sp_row'     => 1,
			'sp_show'    => 3,
			'sp_scroll'  => 3,
			'961'        => array ( 'sp_row' => 1, 'sp_show' => 2, 'sp_scroll' => 2 ),
			'480'        => array ( 'sp_row' => 1, 'sp_show' => 1, 'sp_scroll' => 1 )
		);
		$secretlab['slick'][] = $slick_params;

		$result = new WP_query('post_type=teammate&posts_per_page='.$posts_per_page);

		$output = '';

		//Output posts

		if ( $result->posts ) :

			add_action('wp_footer', 'thelawyer_add_slick_carousel');

			$output .=  '<div id="teamthird" class="carousel '.$slick_params['class'].' team-slide">';

			// Loop through posts
			foreach ( $result->posts as $post ) :

				// Post VARS
				$post_id          = $post->ID;
				if (function_exists("types_render_field")) {
				$member_post = types_render_field("post-of-member", array("post_id" => $post_id, "output"=>"normal"));
				$member_photo = types_render_field("photo-of-member", array("post_id" => $post_id, "output"=>"raw"));
				$fb_profile = types_render_field("facebook-profile", array("post_id" => $post_id, "output"=>"normal"));
				$yt_profile = types_render_field("youtube-profile", array("post_id" => $post_id, "output"=>"normal"));
				$tw_profile = types_render_field("twitter-profile", array("post_id" => $post_id, "output"=>"normal"));
				$bh_profile = types_render_field("behance-profile", array("post_id" => $post_id, "output"=>"normal"));
				$ln_profile = types_render_field("linkedin-profile", array("post_id" => $post_id, "output"=>"normal"));
				$sell_memberphone = types_render_field("thelawyer_member_phone", array("post_id" => $post_id, "output"=>"normal"));
				$sell_memberemail = types_render_field("thelawyer_member_email", array("post_id" => $post_id, "output"=>"normal"));
				} else {$member_post = $member_photo = $fb_profile = $yt_profile = $tw_profile = $bh_profile = $ln_profile = $sell_memberphone = $sell_memberemail = '';}

			$output .= '<div class="team-item team-secondd"><div>';
					$output .= '<div class="photo">
								<a href="' . get_permalink($post_id) . '" rel="bookmark"><img src="' . esc_url($member_photo) . '" alt="" class="img-responsive"/></a>
							</div>
							<span class="name"><a href="' . get_permalink($post_id) . '" rel="bookmark">' . $post->post_title . '</a></span>';
							if (!empty($member_post)) {
								$output .= '<span class="regalies">' . esc_attr($member_post) . '</span>';
							}

								$output .= '<p class="team-overlay-link">';
							if (!empty($fb_profile)) {
								$output .= '<a href="' . esc_url($fb_profile) . '" target="_blank"><i class="icon-facebook"></i></a>';
							}
							if (!empty($yt_profile)) {
								$output .= '<a href="' . esc_url($yt_profile) . '" target="_blank"><i class="icon-youtube-play"></i></a>';
							}
							if (!empty($tw_profile)) {
								$output .= '<a href="' . esc_url($tw_profile) . '" target="_blank"><i class="icon-twitter"></i></a>';
							}
							if (!empty($bh_profile)) {
								$output .= '<a href="' . esc_url($bh_profile) . '" target="_blank"><i class="icon-behance"></i></a>';
							}
							if (!empty($ln_profile)) {
								$output .= '<a href="' . esc_url($ln_profile) . '" target="_blank"><i class="icon-linkedin"></i></a>';
							}
							$output .= '</p></div></div>';

				// End foreach loop
			endforeach;

			$output .= '</div>';


		endif; // End has posts check



		// Set things back to normal
		$result = null;
		wp_reset_postdata();

		// Return output
		return $output;

	}

	vc_map( array(
		'name'        => __( 'Teammates. Layout #3', 'sell' ),
		'base'        => 'teammate_query_third',
		'description' => __( 'Displays 3 teammates in row with carousel', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Extra Class Name', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'May be used for styling with CSS', 'sell' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Posts quantity ', 'sell' ),
				'param_name'	=> 'posts_per_page',
				'description'	=> __( 'how many posts to retrive on page', 'sell' ),
				'value'         => 10
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable navigation', 'sell' ),
				'param_name'	=> 'enable_nav',
				'description'	=> __( 'set ability of navigation', 'sell' ),
				'value'         => array( 'disable' => 'false',
					'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Enable\disable autoplay', 'sell' ),
				'param_name'	=> 'autoplay',
				'description'	=> __( 'set autoplay on/off', 'sell' ),
				'value'         => array( 'disable' => 'false',
					'enable'  => 'true', ),
				'default'       => 'true'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Duration between slides in ms', 'sell' ),
				'param_name'	=> 'speed',
				'description'	=> __( 'time of pause between slides leaf', 'sell' ),
				'value'         => 5000
			)

		)
	));
	

	add_shortcode( 'price_table1', 'price_table1_shortcode' );

	function price_table1_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
			'uid'                   => '',
			'extra_class'           => '',
			'title1'                 => 'Title',
			'subtitle1'              => 'Subtitle',
			'best_offer1'             => false,
			'contents1'              => '',
			'last_line1'             => 'Price',
			'href1'                  => '#',
			'order_button_text1'     => 'order!',
			
			'title2'                 => 'Title',
			'subtitle2'              => 'Subtitle',
			'best_offer2'             => false,		
			'contents2'              => '',
			'last_line2'             => 'Price',
			'href2'                  => '#',
			'order_button_text2'     => 'order!',

			'title3'                 => 'Title',
			'subtitle3'              => 'Subtitle',
			'best_offer3'             => false,		
			'contents3'              => '',
			'last_line3'             => 'Price',
			'href3'                  => '#',
			'order_button_text3'     => 'order!',

			'title4'                 => 'Title',
			'subtitle4'              => 'Subtitle',
			'best_offer4'             => false,		
			'contents4'              => '',
			'last_line4'             => 'Price',
			'href4'                  => '#',
			'order_button_text4'     => 'order!'		
		), $atts ) ); 
		
		$j = 0;
		
		$out = '
		<div class="row center-price '.$extra_class.'">';
			for ($i = 1; $i <= 4; $i++) {
				$title = 'title'.$i;
				$subtitle = 'subtitle'.$i;
				$best_offer = 'best_offer'.$i;
				$contents = 'contents'.$i;
				$last_line = 'last_line'.$i;
				$href = 'href'.$i;
				$order_button_text = 'order_button_text'.$i;
				
				if (!preg_match('/<li>/', html_entity_decode($$contents))) continue;

				$j++;
				if ($$best_offer) $best_offer_class = ' class="bestgreen"'; else $best_offer_class = '';
				
				$out .= '
				
				<div class="col-lg-#n# col-md-#n# col-sm-12 col-xs-12">
					<ul class="pricetable1">
						<li'.$best_offer_class.'>
							<h3>';
								if ($$subtitle != 'Subtitle') {
									$out .= '<span>'.$$subtitle.'</span>';
								}
								$out .= $$title.
							'</h3>
						</li>';
			
				preg_match_all('/<li>(.+)<\/li>/Uims', html_entity_decode($$contents), $lines);

				if (count($lines[0]) > 0) {
					foreach ($lines[0] as $line) {		    
						$out .= $line;
					}
				}
		
				$out .= '<li class="worth">'.$$last_line.'</li>';
		
				$out .= '<li><a class="btn btn-second" href="'.$$href.'"><span class="icon icon-compass2"></span>'.$$order_button_text.'</a></li>';
		
				$out .= '</ul>
			</div>';
			}
			
		$out .= '</div>';
		
		//if ($j > 1) $j = $j - 1; else $j = $j;
		
		$n = 12/$j;
		
		$out = preg_replace('/#n#/', $n, $out);
		
		return $out;
		
	}

	vc_map( array(
		'name'        => __( 'Price Table Layout#1', 'symple' ),
		'base'        => 'price_table1',
		'description' => __( 'Echoes Price Table#1', 'symple' ),
		'category'    => __( 'SecretLab', 'symple' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Unique ID', 'sell' ),
				'param_name'	=> 'uid',
				'description'	=> __( 'May be used for styling', 'sell' ),
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Extra class ', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'extra css class', 'sell' )
			),	
			
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'sell' ),
				'param_name'	=> 'title1',
				'description'	=> __( 'Main title - column will appear if Title field filled', 'sell' ),
				'group'         => 'Column #1'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Subtitle', 'sell' ),
				'param_name'	=> 'subtitle1',
				'description'	=> __( 'subtitle', 'sell' ),
				'group'         => 'Column #1'
			),	
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Best Offer', 'sell' ),
				'param_name'	=> 'best_offer1',
				'description'	=> __( 'set to TRUE, if you want to set to column Best Offer style', 'sell' ),
				'value'         => array( 'false' => 'false',
										  'true'  => 'true' ),			
				'group'         => 'Column #1'
			),				
			array(
				'type'			=> 'textarea',
				'heading'		=> __( 'Content', 'sell' ),
				'param_name'	=> 'contents1',
				'description'	=> __( 'item contents, each item must be bordered in "(_"..."_)"', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Pricing line', 'sell' ),
				'param_name'	=> 'last_line1',
				'description'	=> __( 'contetnt for the pricing area', 'sell' ),
				'group'         => 'Column #1'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Form URL', 'sell' ),
				'param_name'	=> 'href1',
				'description'	=> __( 'url of handler od this block', 'sell' ),
				'group'         => 'Column #1'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Order Button Text', 'sell' ),
				'param_name'	=> 'order_button_text1',
				'description'	=> __( 'contetnt for the order button', 'sell' ),
				'group'         => 'Column #1'
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'sell' ),
				'param_name'	=> 'title2',
				'description'	=> __( 'Main title - column will appear if Title field filled', 'sell' ),
				'group'         => 'Column #2'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Subtitle', 'sell' ),
				'param_name'	=> 'subtitle2',
				'description'	=> __( 'subtitle', 'sell' ),
				'group'         => 'Column #2'
			),	
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Best Offer', 'sell' ),
				'param_name'	=> 'best_offer2',
				'description'	=> __( 'set to TRUE, if you want to set to column Best Offer style', 'sell' ),
				'value'         => array( 'false' => 'false',
										  'true'  => 'true' ),			
				'group'         => 'Column #2'
			),			
			array(
				'type'			=> 'textarea',
				'heading'		=> __( 'Content', 'sell' ),
				'param_name'	=> 'contents2',
				'description'	=> __( 'item contents, each item must be bordered in "(_"..."_)"', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Pricing line', 'sell' ),
				'param_name'	=> 'last_line2',
				'description'	=> __( 'contetnt for the pricing area', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Form URL', 'sell' ),
				'param_name'	=> 'href2',
				'description'	=> __( 'url of handler od this block', 'sell' ),
				'group'         => 'Column #2'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Order Button Text', 'sell' ),
				'param_name'	=> 'order_button_text2',
				'description'	=> __( 'contetnt for the order button', 'sell' ),
				'group'         => 'Column #2'
			),
			
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'sell' ),
				'param_name'	=> 'title3',
				'description'	=> __( 'Main title - column will appear if Title field filled', 'sell' ),
				'group'         => 'Column #3'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Subtitle', 'sell' ),
				'param_name'	=> 'subtitle3',
				'description'	=> __( 'subtitle', 'sell' ),
				'group'         => 'Column #3'
			),	
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Best Offer', 'sell' ),
				'param_name'	=> 'best_offer3',
				'description'	=> __( 'set to TRUE, if you want to set to column Best Offer style', 'sell' ),
				'value'         => array( 'false' => 'false',
										  'true'  => 'true' ),
				'group'         => 'Column #3'
			),			
			array(
				'type'			=> 'textarea',
				'heading'		=> __( 'Content', 'sell' ),
				'param_name'	=> 'contents3',
				'description'	=> __( 'item contents, each item must be bordered in "(_"..."_)"', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Pricing line', 'sell' ),
				'param_name'	=> 'last_line3',
				'description'	=> __( 'contetnt for the pricing area', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Form URL', 'sell' ),
				'param_name'	=> 'href3',
				'description'	=> __( 'url of handler od this block', 'sell' ),
				'group'         => 'Column #3'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Order Button Text', 'sell' ),
				'param_name'	=> 'order_button_text2',
				'description'	=> __( 'contetnt for the order button', 'sell' ),
				'group'         => 'Column #3'
			),		

			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Title', 'sell' ),
				'param_name'	=> 'title4',
				'description'	=> __( 'Main title - column will appear if Title field filled', 'sell' ),
				'group'         => 'Column #4'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Subtitle', 'sell' ),
				'param_name'	=> 'subtitle4',
				'description'	=> __( 'subtitle', 'sell' ),
				'group'         => 'Column #4'
			),	
			array(
				'type'			=> 'dropdown',
				'heading'		=> __( 'Best Offer', 'sell' ),
				'param_name'	=> 'best_offer4',
				'description'	=> __( 'set to TRUE, if you want to set to column Best Offer style', 'sell' ),
				'value'         => array( 'false' => 'false',
										  'true'  => 'true' ),			
				'group'         => 'Column #4'
			),			
			array(
				'type'			=> 'textarea',
				'heading'		=> __( 'Content', 'sell' ),
				'param_name'	=> 'contents4',
				'description'	=> __( 'item contents, each item must be bordered in "(_"..."_)"', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Pricing line', 'sell' ),
				'param_name'	=> 'last_line4',
				'description'	=> __( 'contetnt for the pricing area', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Form URL', 'sell' ),
				'param_name'	=> 'href4',
				'description'	=> __( 'url of handler od this block', 'sell' ),
				'group'         => 'Column #4'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Order Button Text', 'sell' ),
				'param_name'	=> 'order_button_text4',
				'description'	=> __( 'contetnt for the order button', 'sell' ),
				'group'         => 'Column #4'
			)		
			
		)
	));


	add_shortcode( 'price_table2', 'price_table2_shortcode' );

	function price_table2_shortcode($atts, $content = null) {
		extract( shortcode_atts( array(
			'uid'                   => '',
			'extra_class'           => '',
			'title1'                => '',
			'title2'                => '',
			'title3'                => '',
			'title4'                => '',
			'title5'                => '',
			'title6'                => '',
			'title7'                => '',
			'title8'                => '',
			'title9'                => '',
			'title10'               => '',
			'title11'               => '',
			'column1_title'         => '',
			'column1_recommended'   => '',
			'column1_line1'         => '',
			'column1_line2'         => '',
			'column1_line3'         => '',
			'column1_line4'         => '',
			'column1_line5'         => '',	
			'column1_line6'         => '',	
			'column1_line7'         => '',	
			'column1_line8'         => '',
			'column1_line9'         => '',	
			'column1_line10'        => '',	
			'column1_line11'        => '',			
			'order_text1'           => 'order1',
			'order_link1'           => '',
			'column2_title'         => '',
			'column2_recommended'   => '',
			'column2_line1'         => '',
			'column2_line2'         => '',
			'column2_line3'         => '',
			'column2_line4'         => '',
			'column2_line5'         => '',	
			'column2_line6'         => '',	
			'column2_line7'         => '',	
			'column2_line8'         => '',
			'column2_line9'         => '',	
			'column2_line10'        => '',	
			'column2_line11'        => '',			
			'order_text2'           => 'order2',
			'order_link2'           => '',
			'column3_title'         => '',
			'column3_recommended'   => '',
			'column3_line1'         => '',
			'column3_line2'         => '',
			'column3_line3'         => '',
			'column3_line4'         => '',
			'column3_line5'         => '',	
			'column3_line6'         => '',	
			'column3_line7'         => '',	
			'column3_line8'         => '',
			'column3_line9'         => '',	
			'column3_line10'        => '',	
			'column3_line11'        => '',			
			'order_text3'           => 'order3',
			'order_link3'           => '',
			'column4_title'         => '',
			'column4_recommended'   => '',
			'column4_line1'         => '',
			'column4_line2'         => '',
			'column4_line3'         => '',
			'column4_line4'         => '',
			'column4_line5'         => '',	
			'column4_line6'         => '',	
			'column4_line7'         => '',	
			'column4_line8'         => '',
			'column4_line9'         => '',	
			'column4_line10'        => '',	
			'column4_line11'        => '',			
			'order_text4'           => 'order4',
			'order_link4'           => '',
			'column5_title'         => '',
			'column5_recommended'   => '',
			'column5_line1'         => '',
			'column5_line2'         => '',
			'column5_line3'         => '',
			'column5_line4'         => '',
			'column5_line5'         => '',	
			'column5_line6'         => '',	
			'column5_line7'         => '',	
			'column5_line8'         => '',
			'column5_line9'         => '',	
			'column5_line10'        => '',
			'column5_line11'        => '',			
			'order_text5'           => 'order5',
			'order_link5'           => '',		
		), $atts ) ); 
		
		$title_out = '<div class="row center-price zeopadding">
					<div class="col-lg-#n# col-md-#n# col-sm-#n# col-xs-6 pl0 pr0">
						<ul class="pricetable2caption">
							<li><h3>&nbsp;</h3></li>';
		$column_out = '';
		$out = '';
		$n = 0; $price_lines = array();
		
		for ($i = 1; $i <= 11; $i++) {
			$title = 'title'.$i;
			if ($$title == '' || !$$title) continue;
			if (preg_match('/#price_line#/', $$title)) {
				$$title = preg_replace('/#price_line#/', '', $$title);
				$price_lines[] = $i;
			}		
			$title_out .= '<li>'.$$title.'</li>';
		}
		$title_out .= '</ul></div>';
		
		for ($j = 1; $j <= 5; $j++) {
			$column_title = 'column'.$j.'_title';
			if ($$column_title == '' || !$$column_title) continue;
			$column_recommended = 'column'.$j.'_recommended';
			if ($$column_recommended == 'true') { $r_ul_class = ' recommended'; $r_li_class = 'class="pro"'; } else { $r_ul_class = $r_li_class = ''; }
			$order_text = 'order_text'.$j;
			$column_out .= '<div class="col-lg-#n# col-md-#n# col-sm-#n# col-xs-6 pl0 pr0">
							   <ul class="pricetable2'.$r_ul_class.'">
								   <li '.$r_li_class.'><h3>'.$$column_title.'</h3></li>';			
			for ($k = 1; $k <= 11; $k++) {
				$column_line = 'column'.$j.'_line'.$k;
				$$column_line = html_entity_decode($$column_line);
				if ($$column_line == '' || !$$column_line) continue;
					$worth_class = '';
					if ($$column_line == 'tick') $content = '<span class="icon icon-check"></span>';
					else if ($$column_line == 'mark') $content = '<span class="icon icon-cross2"></span>';
					else $content = $$column_line;
					if (in_array($k, $price_lines)) {
						$worth_class = ' class="worth"';
					}
					$column_out .= '<li'.$worth_class.'>'.$content.'</li>';
			}
			$order_link = 'order_link'.$j;
			$link = vc_build_link($$order_link);
			$column_out .=	'<li><a class="btn btn-info" href="'.$link['url'].'" title="'.$link['title'].'">
								 <span class="icon icon-compass2"></span>'.$$order_text.'
							 </a></li>
							</ul>
						</div>';
			$n++;			
		}	
		
		$out = $title_out.$column_out.'<div class="clearfix"></div>';
		$rest = 12 % ($n + 1);
		if ($rest == 0) $n = 12/($n + 1); else $n = 2;
		
		$out = preg_replace('/#n#/', $n, $out);
		
		return $out;
		
	}

	vc_map( array(
		'name'        => __( 'Price Table Layout#2', 'sell' ),
		'base'        => 'price_table2',
		'description' => __( 'Echoes Price Table#2', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Unique ID', 'sell' ),
				'param_name'	=> 'uid',
				'description'	=> __( 'May be used for styling', 'sell' ),
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Extra class ', 'sell' ),
				'param_name'	=> 'extra_class',
				'description'	=> __( 'extra css class', 'sell' )
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #1 Title', 'sell' ),
				'param_name'	=> 'title1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #2 Title', 'sell' ),
				'param_name'	=> 'title2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #3 Title', 'sell' ),
				'param_name'	=> 'title3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #4 Title', 'sell' ),
				'param_name'	=> 'title4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #5 Title', 'sell' ),
				'param_name'	=> 'title5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #6 Title', 'sell' ),
				'param_name'	=> 'title6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #7 Title', 'sell' ),
				'param_name'	=> 'title7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #8 Title', 'sell' ),
				'param_name'	=> 'title8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #9 Title', 'sell' ),
				'param_name'	=> 'title9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #10 Title', 'sell' ),
				'param_name'	=> 'title10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Line #11 Title', 'sell' ),
				'param_name'	=> 'title11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Line Titles'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Title', 'sell' ),
				'param_name'	=> 'column1_title',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),		
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Column #1 Recommended Sign', 'sell' ),
				'param_name'	=> 'column1_recommended',
				'description'	=> __( '', 'sell' ),
				'value'         => array ( 'Off' => 'false',
										   'On'  => 'true' ),
				'default'       => 'Off',
				'group'         => 'Column #1'
			),			
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #1 Content', 'sell' ),
				'param_name'	=> 'column1_line1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #2 Content', 'sell' ),
				'param_name'	=> 'column1_line2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #3 Content', 'sell' ),
				'param_name'	=> 'column1_line3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #4 Content', 'sell' ),
				'param_name'	=> 'column1_line4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #5 Content', 'sell' ),
				'param_name'	=> 'column1_line5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #6 Content', 'sell' ),
				'param_name'	=> 'column1_line6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #7 Content', 'sell' ),
				'param_name'	=> 'column1_line7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #8 Content', 'sell' ),
				'param_name'	=> 'column1_line8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #9 Content', 'sell' ),
				'param_name'	=> 'column1_line9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #10 Content', 'sell' ),
				'param_name'	=> 'column1_line10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Line #11 Content', 'sell' ),
				'param_name'	=> 'column1_line11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #1 Order Button Caption', 'sell' ),
				'param_name'	=> 'order_text1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'Column #1 Order Button Link', 'sell' ),
				'param_name'	=> 'order_link1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #1'
			),		
			
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Title', 'sell' ),
				'param_name'	=> 'column2_title',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),		
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Column #2 Recommended Sign', 'sell' ),
				'param_name'	=> 'column2_recommended',
				'description'	=> __( '', 'sell' ),
				'value'         => array ( 'Off' => 'false',
										   'On'  => 'true' ),
				'default'       => 'Off',						   
				'group'         => 'Column #2'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #1 Content', 'sell' ),
				'param_name'	=> 'column2_line1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #2 Content', 'sell' ),
				'param_name'	=> 'column2_line2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #3 Content', 'sell' ),
				'param_name'	=> 'column2_line3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #4 Content', 'sell' ),
				'param_name'	=> 'column2_line4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #5 Content', 'sell' ),
				'param_name'	=> 'column2_line5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #6 Content', 'sell' ),
				'param_name'	=> 'column2_line6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #7 Content', 'sell' ),
				'param_name'	=> 'column2_line7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #8 Content', 'sell' ),
				'param_name'	=> 'column2_line8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #9 Content', 'sell' ),
				'param_name'	=> 'column2_line9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #10 Content', 'sell' ),
				'param_name'	=> 'column2_line10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Line #11 Content', 'sell' ),
				'param_name'	=> 'column2_line11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #2 Order Button Caption', 'sell' ),
				'param_name'	=> 'order_text2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),	
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'Column #2 Order Button Link', 'sell' ),
				'param_name'	=> 'order_link2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #2'
			),		

			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Title', 'sell' ),
				'param_name'	=> 'column3_title',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),		
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Column #3 Recommended Sign', 'sell' ),
				'param_name'	=> 'column3_recommended',
				'description'	=> __( '', 'sell' ),
				'value'         => array ( 'Off' => 'false',
										   'On'  => 'true' ),
				'default'       => 'Off',						   
				'group'         => 'Column #3'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #1 Content', 'sell' ),
				'param_name'	=> 'column3_line1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #2 Content', 'sell' ),
				'param_name'	=> 'column3_line2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #3 Content', 'sell' ),
				'param_name'	=> 'column3_line3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #4 Content', 'sell' ),
				'param_name'	=> 'column3_line4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #5 Content', 'sell' ),
				'param_name'	=> 'column3_line5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #6 Content', 'sell' ),
				'param_name'	=> 'column3_line6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #7 Content', 'sell' ),
				'param_name'	=> 'column3_line7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #8 Content', 'sell' ),
				'param_name'	=> 'column3_line8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #9 Content', 'sell' ),
				'param_name'	=> 'column3_line9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #10 Content', 'sell' ),
				'param_name'	=> 'column3_line10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Line #11 Content', 'sell' ),
				'param_name'	=> 'column3_line11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #3 Order Button Caption', 'sell' ),
				'param_name'	=> 'order_text3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'Column #3 Order Button Link', 'sell' ),
				'param_name'	=> 'order_link3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #3'
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Title', 'sell' ),
				'param_name'	=> 'column4_title',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),		
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Column #4 Recommended Sign', 'sell' ),
				'param_name'	=> 'column4_recommended',
				'description'	=> __( '', 'sell' ),
				'value'         => array ( 'Off' => 'false',
										   'On'  => 'true' ),
				'default'       => 'Off',						   
				'group'         => 'Column #4'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #1 Content', 'sell' ),
				'param_name'	=> 'column4_line1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #2 Content', 'sell' ),
				'param_name'	=> 'column4_line2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #3 Content', 'sell' ),
				'param_name'	=> 'column4_line3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #4 Content', 'sell' ),
				'param_name'	=> 'column4_line4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #5 Content', 'sell' ),
				'param_name'	=> 'column4_line5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #6 Content', 'sell' ),
				'param_name'	=> 'column4_line6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #7 Content', 'sell' ),
				'param_name'	=> 'column4_line7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #8 Content', 'sell' ),
				'param_name'	=> 'column4_line8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #9 Content', 'sell' ),
				'param_name'	=> 'column4_line9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #10 Content', 'sell' ),
				'param_name'	=> 'column4_line10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Line #11 Content', 'sell' ),
				'param_name'	=> 'column4_line11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #4 Order Button Caption', 'sell' ),
				'param_name'	=> 'order_text4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'Column #4 Order Button Link', 'sell' ),
				'param_name'	=> 'order_link4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #4'
			),	

			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Title', 'sell' ),
				'param_name'	=> 'column5_title',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),		
			array(
				'type'			=> 'checkbox',
				'heading'		=> __( 'Column #5 Recommended Sign', 'sell' ),
				'param_name'	=> 'column5_recommended',
				'description'	=> __( '', 'sell' ),
				'value'         => array ( 'Off' => 'false',
										   'On'  => 'true' ),
				'default'       => 'Off',						   
				'group'         => 'Column #5'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #1 Content', 'sell' ),
				'param_name'	=> 'column5_line1',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #2 Content', 'sell' ),
				'param_name'	=> 'column5_line2',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #3 Content', 'sell' ),
				'param_name'	=> 'column5_line3',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #4 Content', 'sell' ),
				'param_name'	=> 'column5_line4',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #5 Content', 'sell' ),
				'param_name'	=> 'column5_line5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #6 Content', 'sell' ),
				'param_name'	=> 'column5_line6',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #7 Content', 'sell' ),
				'param_name'	=> 'column5_line7',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #8 Content', 'sell' ),
				'param_name'	=> 'column5_line8',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #9 Content', 'sell' ),
				'param_name'	=> 'column5_line9',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #10 Content', 'sell' ),
				'param_name'	=> 'column5_line10',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Line #11 Content', 'sell' ),
				'param_name'	=> 'column5_line11',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),		
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Column #5 Order Button Caption', 'sell' ),
				'param_name'	=> 'order_text5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'Column #5 Order Button Link', 'sell' ),
				'param_name'	=> 'order_link5',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Column #5'
			),		
		)
	));


	// WHY US SHORTCODE
	add_shortcode( 'why_us', 'why_us_shortcode' );


	if ( ! function_exists('why_us_shortcode') ) {

		function why_us_shortcode($atts, $content = null) {

			$home = get_stylesheet_uri().'/';

			$vals = shortcode_atts( array(
				'uid'          => '',
				'extra_class'  => '',
				'bg_image'     => 662,
				'title'        => 'Why Us?',
				'subtitle'     => 'Our professional lawyers have rich experience, and a track record of winning cases',

				'bg_alt1'      => 'Global reach',   'bg_alt2'    => 'Best Prices',    'bg_alt3'    => 'Big Experience',    'bg_alt4'    => 'Convenience',    'bg_alt5'    => 'Team Strength',
				'bg_src1'      => '470',       'bg_src2'    => '469',        'bg_src3'    => '467',        'bg_src4'    => '466',    'bg_src5'    => '459',
				'alt1'         => 'Global reach',      'alt2'       => 'Best Prices',  'alt3' =>  'Big Experience',       'alt4'       => 'Convenience',       'alt5'       => 'Team Strength',
				'src1'         => '679',       'src2'       => '680',       'src3'       => '677',         'src4'       => '678',       'src5'       => '663',
				'content1'     => 'Global Reach',  'content2'   => 'Best Prices',   'content3'   => 'Big Experience',   'content4'   => 'Convenience',   'content5'   => 'Team Strength',
				'color1'       => 'blue',    'color2'     => 'blue',     'color3'     => 'green',     'color4'     => 'blue',     'color5'     => 'green'

			), $atts );

			$inline_style = '';
			if (isset($vals['bg_image']) && $vals['bg_image'] != '') {
				$image = wp_get_attachment_url( $vals['bg_image'] );
				$inline_style = ' style="background-image:url('."'".$image."'".');"';
			}

			$out = '
		<section class="benefits">
			<div class="beninside"'.$inline_style.'>
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="why">
							<div class="headinginfo">
								<h2>'.$vals['title'].'</h2>'.$vals['subtitle'].'
							</div>
						</div>';
			for ($i = 1; $i <=5; $i++) {

				$bg_alt = 'bg_alt'.$i;
				$bg_src = 'bg_src'.$i;
				$alt = 'alt'.$i;
				$src = 'src'.$i;
				$content = 'content'.$i;
				$color = 'color'.$i;

				$out .= '
							<div class="rhombus beniconsize'.$i.'">
								<div class="tralign">
										<img class="imgbgr" alt="'.$vals[$bg_alt].'" src="'.wp_get_attachment_url($vals[$bg_src]).'">
									<div class="beniconblock '.$vals[$color].'bgr bico o0-o02">
										<img alt="'.$vals[$alt].'" src="'.wp_get_attachment_url($vals[$src]).'">
										<b>'.$vals[$content].'</b>
									</div>
								</div>
							</div>';

			}
			$out .= '
					<div class="clearfix"></div></div>
				</div>
			</div>
			</div>
		</section>';

			return $out;

		}

	}

	vc_map( array(
			'name'        => __( 'Why Us Block Layout', 'symple' ),
			'base'        => 'why_us',
			'description' => __( 'Echoes Why Us Block', 'sell' ),
			'category'    => __( 'SecretLab', 'sell' ),
			'icon'        => 'ss-vc-icon icon-arrows-h',
			'params'      => array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'Unique ID', 'symple' ),
					'param_name'	=> 'uid',
					'description'	=> __( 'May be used for styling', 'sell' ),
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'Extra class ', 'sell' ),
					'param_name'	=> 'extra_class',
					'description'	=> __( 'extra css class', 'sell' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'Title', 'sell' ),
					'param_name'	=> 'title',
					"value"         => "Why Us?",
					'description'	=> __( 'Main title', 'sell' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'Subitle', 'sell' ),
					'param_name'	=> 'subtitle',
					"value"         => "We offer synergistic online products, social media marketing and dynamic SEO strategies deliverin.",
					'description'	=> __( 'Subtitle', 'sell' )
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'Background Image', 'sell' ),
					'param_name'	=> 'bg_image',
					"value"         => 409,
					'description'	=> __( '', 'sell' )
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for background #1', 'symple' ),
					'param_name'	=> 'bg_alt1',
					"value"         => "Global reach",
					'description'	=> __( 'alt attribute', 'sell' ),
					'group'         => 'block 1'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'background image for block #1', 'symple' ),
					'param_name'	=> 'bg_src1',
					'description'	=> __( 'background image', 'sell' ),
					'group'         => 'block 1'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for main image in block #1', 'symple' ),
					'param_name'	=> 'alt1',
					"value"         => "Global reach",
					'description'	=> __( 'alt attribute for main image', 'sell' ),
					'group'         => 'block 1'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'main image for block #1', 'symple' ),
					'param_name'	=> 'src1',
					'description'	=> __( 'main image', 'sell' ),
					'group'         => 'block 1'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'text content #1', 'sell' ),
					'param_name'	=> 'content1',
					"value"         => "Global reach",
					'description'	=> __( 'content for block #1', 'sell' ),
					'group'         => 'block 1'
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> __( 'background color for block #1', 'symple' ),
					'param_name'	=> 'color1',
					'description'	=> __( 'background color #1', 'sell' ),
					'value'         => array ( 'white' => 'white',
						'green' => 'green',
						'blue'  => 'blue' ),
					'group'         => 'block 1'
				),


				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for background #2', 'symple' ),
					'param_name'	=> 'bg_alt2',
					'description'	=> __( 'alt attribute', 'sell' ),
					'value'         => 'Best Prices',
					'group'         => 'block 2'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'background image for block #2', 'symple' ),
					'param_name'	=> 'bg_src2',
					'description'	=> __( 'background image', 'sell' ),
					'group'         => 'block 2'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for main image in block #2', 'symple' ),
					'param_name'	=> 'alt2',
					'description'	=> __( 'alt attribute for main image', 'sell' ),
					'value'         => 'Best Prices',
					'group'         => 'block 2'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'main image for block #2', 'symple' ),
					'param_name'	=> 'src2',
					'description'	=> __( 'main image', 'sell' ),
					'group'         => 'block 2'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'text content #2', 'symple' ),
					'param_name'	=> 'content2',
					'description'	=> __( 'content for block #2', 'sell' ),
					'value'         => 'Best Prices',
					'group'         => 'block 2'
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> __( 'background color for block #2', 'symple' ),
					'param_name'	=> 'color2',
					'description'	=> __( 'background color #2', 'sell' ),
					'value'         => array ( 'white' => 'white',
						'green' => 'green',
						'blue'  => 'blue' ),
					'group'         => 'block 2'
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for background #3', 'symple' ),
					'param_name'	=> 'bg_alt3',
					'description'	=> __( 'alt attribute', 'sell' ),
					'value'         => 'Big Expirience',
					'group'         => 'block 3'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'background image for block #3', 'symple' ),
					'param_name'	=> 'bg_src3',
					'description'	=> __( 'background image', 'sell' ),
					'group'         => 'block 3'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for main image in block #3', 'symple' ),
					'param_name'	=> 'alt3',
					'description'	=> __( 'alt attribute for main image', 'sell' ),
					'value'         => 'Big Expirience',
					'group'         => 'block 3'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'main image for block #3', 'symple' ),
					'param_name'	=> 'src3',
					'description'	=> __( 'main image', 'sell' ),
					'group'         => 'block 3'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'text content #3', 'symple' ),
					'param_name'	=> 'content3',
					'description'	=> __( 'content for block #3', 'sell' ),
					'value'         => 'Big Expirience',
					'group'         => 'block 3'
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> __( 'background color for block #3', 'symple' ),
					'param_name'	=> 'color3',
					'description'	=> __( 'background color #3', 'sell' ),
					'value'         => array ( 'white' => 'white',
						'green' => 'green',
						'blue'  => 'blue' ),
					'group'         => 'block 3'
				),


				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for background #4', 'symple' ),
					'param_name'	=> 'bg_alt4',
					'description'	=> __( 'alt attribute', 'sell' ),
					'value'         => 'Convenience',
					'group'         => 'block 4'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'background image for block #4', 'symple' ),
					'param_name'	=> 'bg_src4',
					'description'	=> __( 'background image', 'sell' ),
					'group'         => 'block 4'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for main image in block #4', 'symple' ),
					'param_name'	=> 'alt4',
					'description'	=> __( 'alt attribute for main image', 'sell' ),
					'value'         => 'Convenience',
					'group'         => 'block 4'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'main image for block #4', 'sell' ),
					'param_name'	=> 'src4',
					'description'	=> __( 'main image', 'sell' ),
					'group'         => 'block 4'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'text content #4', 'sell' ),
					'param_name'	=> 'content4',
					'description'	=> __( 'content for block #4', 'sell' ),
					'value'         => 'Convenience',
					'group'         => 'block 4'
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> __( 'background color for block #4', 'sell' ),
					'param_name'	=> 'color4',
					'description'	=> __( 'background color #4', 'sell' ),
					'value'         => array ( 'white' => 'white',
						'green' => 'green',
						'blue'  => 'blue' ),
					'group'         => 'block 4'
				),


				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for background #5', 'sell' ),
					'param_name'	=> 'bg_alt5',
					'description'	=> __( 'alt attribute', 'sell' ),
					'value'         => 'Team Strength',
					'group'         => 'block 5'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'background image for block #5', 'sell' ),
					'param_name'	=> 'bg_src5',
					'description'	=> __( 'background image', 'sell' ),
					'group'         => 'block 5'
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __( 'alt attribute for main image in block #5', 'symple' ),
					'param_name'	=> 'alt5',
					'description'	=> __( 'alt attribute for main image', 'sell' ),
					'value'         => 'Team Strength',
					'group'         => 'block 5'
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> __( 'main image for block #5', 'sell' ),
					'param_name'	=> 'src5',
					'description'	=> __( 'main image', 'sell' ),
					'group'         => 'block 5'
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __( 'text content #5', 'symple' ),
					'param_name'	=> 'content5',
					'description'	=> __( 'content for block #4', 'sell' ),
					'value'         => 'Team Strength',
					'group'         => 'block 5'
				),
				array(
					'type'			=> 'dropdown',
					'heading'		=> __( 'background color for block #5', 'symple' ),
					'param_name'	=> 'color5',
					'description'	=> __( 'background color #5', 'sell' ),
					'value'         => array ( 'white' => 'white',
						'green' => 'green',
						'blue'  => 'blue' ),
					'group'         => 'block 5'
				),

			)
		)
	);

	/* Social Icons */
	require_once( plugin_dir_path( __FILE__ ) . 'sl_social_icons.php' );
	require_once( plugin_dir_path( __FILE__ ) . 'blog_one_three.php' );
	require_once( plugin_dir_path( __FILE__ ) . 'sl_mega_icons/sl_mega_icons.php' );
	//require_once( plugin_dir_path( __FILE__ ) . 'teammate_shortcode.php' );

}
		


?>
