<?php

/*
* Social Icon Shortcode
*/

    add_shortcode( 'sl_social_icons', 'sl_social_icons_shortcode' );

	if ( ! function_exists('sl_social_icons_shortcode') ) {
	
	    function sl_social_icons_shortcode ($atts, $content = null) {
		
		    $defaults = array( 'twitter_url' => false,
			                   'facebook_url' => false,
							   'myspace_url' => false,
							   'linkedin_url' => false,
							   'google_url' => false,
							   'tumbrl_url' => false,
							   'pinterest_url' => false,
							   'youtube_url' => false,
							   'instagram_url' => false,
							   'vk_url' => false,
							   'reddit_url' => false,
							   'blogger_url' => false,
							   'wordpress_url' => false,
							   'behance_url' => false,
							   );

            $style = array ( 'class'  => '',
			                 'height' => '40px',
							 'width' => '40px',
							 'container_background_color' => '#000000',
							 'border_radius' => '5px',
							 'font_size' => '14px',
							 'font_color' => '#ffffff',
							 'hover_font_color' => '#f5f5f5',
							 'hover_background_color' => '#353535',
							 'css' => '' );
							 
			$class_names = array( 'twitter' => 'icon-twitter',
			                      'facebook' => 'icon-facebook',
								  'myspace' => 'icon-users',
								  'linkedin' => 'icon-linkedin',
								  'google' => 'icon-google-plus',
								  'tumbrl' => 'icon-tumblr',
								  'pinterest' => 'icon-pinterest-p',
								  'youtube' => 'icon-youtube-play',
								  'instagram' => 'icon-instagram',
								  'vk' => 'icon-vk',
								  'reddit' => 'icon-reddit',
								  'blogger' => 'icon-pencil6',
								  'wordpress' => 'icon-wordpress',
								  'behance' => 'icon-behance' );
								  
								
					   
			$args = vc_map_get_attributes( 'sl_social_icons', $atts );
            $urls = shortcode_atts( $defaults, $args );	
            $style = shortcode_atts( $style, $args ); 
			
			preg_match('/{([^{]+)}/ims', $style['css'], $rules);
            if ( isset( $rules ) && isset ( $rules[1] ) ) $rules = ' style="' . $rules[1] . '"'; else $rules = '';			
			
			$css_class = apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $style['css'], ' ' ), 'sl_social_icons', $atts );
			$class = $style['class'] == '' ? '' : ' ' . $style['class'];

			$echo = false;
			$out  =  '<style type="text/css">.sell_socials li a { height : ' . $style['height'] . '; width : ' . $style['width'] . '; background-color : ' . $style['container_background_color'] . '; border-radius : ' . $style['border_radius'] . '; }
			';
			$out .=  '.sell_socials li a { font-size : ' . $style['font_size'] . '; color : ' . $style['font_color'] . '; }
			';			
			$out .=  '.sell_socials li a:hover { color : ' . $style['hover_font_color'] . '; background-color : ' . $style['hover_background_color'] . '; }
			';
			$out .=  '.sell_socials li a i {  line-height : ' . $style['height'] . '; }
			';
			$out .=  '</style>';
            foreach ( $urls as $name => $url ) { if ( $url != false ) { $echo = true; break; } }
			if ( $echo ) {
			    $out .= '<ul class="sell_socials ' . esc_attr($css_class) . esc_attr($class) . '"' . $rules . '>';
				$keys = array_keys ( $defaults );
			    foreach ( $keys as $key ) {
				    if ( isset( $urls[$key] ) && $urls[$key] != false ) {
				        $icon_name = str_ireplace ( '_url', '', $key);
						if ( $class_names[$icon_name] )
				            $out .= '<li><a href="' . esc_url($url) . '" target="_blank"><i class="' . $class_names[$icon_name] . '"></i></a></li>';
					}
				}			
				return $out . '</ul>';
			}
			else return false;
		
		}
	
	}
	
	vc_map( array(
		'name'        => __( 'Social Icons', 'sell' ),
		'base'        => 'sl_social_icons',
		'description' => __( 'Display your socials', 'sell' ),
		'category'    => __( 'SecretLab', 'sell' ),
		'icon'        => 'ss-vc-icon icon-arrows-h',
		'params'      => array(	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'facebook', 'sell' ),
				'param_name'	=> 'facebook_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_facebook')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Twitter', 'sell' ),
				'param_name'	=> 'twitter_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_twitter')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'My Space', 'sell' ),
				'param_name'	=> 'myspace_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_myspace')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Linkedin', 'sell' ),
				'param_name'	=> 'linkedin_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_linkedin')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Google', 'sell' ),
				'param_name'	=> 'google_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_google')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Tumblr', 'sell' ),
				'param_name'	=> 'tumblr_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_tumblr')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Pinterest', 'sell' ),
				'param_name'	=> 'pinterest_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_pinterest')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Youtube', 'sell' ),
				'param_name'	=> 'youtube_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_youtube')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Instagram', 'sell' ),
				'param_name'	=> 'instagram_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_instagram')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'VK', 'sell' ),
				'param_name'	=> 'vk_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_vkcom')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Reddit', 'sell' ),
				'param_name'	=> 'reddit_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_reddit')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Blogger', 'sell' ),
				'param_name'	=> 'blogger_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_blogger')
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Wordpress', 'sell' ),
				'param_name'	=> 'wordpress_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_wordpress')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Behance', 'sell' ),
				'param_name'	=> 'behance_url',
				'description'	=> __( '', 'sell' ),
				'group'         => 'General',
				'value'         => get_sl_option('social_link_behance')
			),
			
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Custom CSS Class', 'sell' ),
				'param_name'	=> 'class',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => ''
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Height', 'sell' ),
				'param_name'	=> 'height',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '40px'
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Width', 'sell' ),
				'param_name'	=> 'width',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '40px'
			),
			array(
				'type'			=> 'colorpicker',
				'heading'		=> __( 'Icon Background Color', 'sell' ),
				'param_name'	=> 'container_background_color',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '#000000'
			),				
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Border Radius', 'sell' ),
				'param_name'	=> 'border_radius',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '5px'
			),	
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Font Size', 'sell' ),
				'param_name'	=> 'font_size',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '14px'
			),	
			array(
				'type'			=> 'colorpicker',
				'heading'		=> __( 'Font Color', 'sell' ),
				'param_name'	=> 'font_color',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '#ffffff'
			),	
			array(
				'type'			=> 'colorpicker',
				'heading'		=> __( 'Hover Font Color', 'sell' ),
				'param_name'	=> 'hover_font_color',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '#f5f5f5'
			),
			array(
				'type'			=> 'colorpicker',
				'heading'		=> __( 'Hover Background Color', 'sell' ),
				'param_name'	=> 'hover_background_color',
				'description'	=> __( '', 'sell' ),
				'group'         => 'Style',
				'value'         => '#353535'
			),
            array(
                'type'          => 'css_editor',
                'heading'       => 'Block Disign Options',
                'param_name'    => 'css',
                'group'         => 'Design Options'				
		    )
		)
	));



?>
